# GovCareer Compass

A personalized Government Career Discovery & Intelligence Platform.

## Initial scope
- Central Government
- West Bengal Government
- English (default)
- Bengali (second language)
- All Indian states visible in the state selector, but only researched states are enabled

## Core promise
**CAN I?** — eligibility intelligence  
**SHOULD I?** — preference-based career matching  
**HOW DO I?** — exam and preparation guidance

## Architecture
GitHub is the source of truth. Vercel is the primary deployment target. The application is static-first and remains compatible with GitHub Pages.

## Golden principles
- Official recruitment notifications and service rules control actual eligibility.
- Facts and analytical assessments are stored separately.
- West Bengal and Central Government pay systems are always distinct.
- Basic pay, gross salary and take-home estimates are distinct.
- Housing entitlement, availability and allotment are distinct.
- Current vacancies are not the definition of a career.
- Promotion is not presented as guaranteed without rule support.
- Important facts carry source/verification metadata.
- No private API keys belong in the public frontend.

## Status
Permanent project architecture/scaffold. Empty production datasets are intentional until verified research is added.
