---
name: Data update
about: Propose a researched government-career data change
title: "[Data] "
labels: data
---

Entity ID:
Change:
Organisation:
Official document:
Date:
Exact URL:
Current/historical:
Confidence:
Notes:
