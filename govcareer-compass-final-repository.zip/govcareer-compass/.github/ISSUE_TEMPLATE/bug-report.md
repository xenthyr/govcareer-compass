---
name: Bug report
about: Report a reproducible issue
title: "[Bug] "
labels: bug
---

Problem:
Steps:
Expected:
Actual:
Device/browser:
