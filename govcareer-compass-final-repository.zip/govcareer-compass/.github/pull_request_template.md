## Change type
- [ ] UI
- [ ] Data
- [ ] Eligibility
- [ ] Recommendation
- [ ] Localization
- [ ] Research/source
- [ ] Bug
- [ ] Documentation

## Verification
- [ ] Source metadata included
- [ ] Currentness reviewed
- [ ] No secrets
- [ ] Validation run
