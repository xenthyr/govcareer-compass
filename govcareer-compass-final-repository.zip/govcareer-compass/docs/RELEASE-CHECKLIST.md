# Release Checklist

## Data
- [ ] No placeholder records in production
- [ ] Every major factual record has source metadata
- [ ] Current/historical status reviewed
- [ ] Pay-system separation verified
- [ ] Eligibility reviewed

## Logic
- [ ] Eligibility tests pass
- [ ] Negative metrics never reward worse conditions
- [ ] Explanations agree with ranking
- [ ] State and language filtering work

## UI
- [ ] Mobile
- [ ] Tablet
- [ ] Desktop
- [ ] Keyboard
- [ ] Reduced motion
- [ ] Print
- [ ] No undefined/null/NaN

## Deployment
- [ ] Vercel production deployment
- [ ] No secrets
- [ ] robots.txt reviewed
- [ ] sitemap updated
