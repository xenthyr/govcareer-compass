# Repository Rules

Do:
- keep public facts in structured data
- keep application logic modular
- use stable IDs
- separate facts from analysis
- version recommendation logic
- keep canonical source records
- validate JSON

Do not:
- commit secrets
- duplicate facts across many pages
- hard-code state-specific rules into generic scoring code
- merge distinct cadres just because names are similar
- treat promotion/deputation/contract records as normal fresh-entry careers
- hide critical information only in hover states
