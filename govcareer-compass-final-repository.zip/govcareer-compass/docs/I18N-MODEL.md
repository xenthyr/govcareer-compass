# Internationalization Model

Default language: `en`
Second language: `bn`

Future languages can be added without changing stable entity IDs.

Rules:
- UI strings live in translation files.
- Official source titles remain available in source form.
- Translation must not alter legal/recruitment meaning.
- Missing translation keys must block release validation.
