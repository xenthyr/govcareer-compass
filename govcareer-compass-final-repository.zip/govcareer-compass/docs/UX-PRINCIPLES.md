# UX Principles

1. Search serves users who know what they want.
2. Career Finder serves users who are unsure.
3. Eligibility comes before ranking.
4. Every recommendation explains why and why-not.
5. Facts and analysis are visually distinct.
6. Burden metrics explicitly state that higher is worse.
7. Mobile users get the same underlying information.
8. Critical facts never depend on hover.
9. Users can change priorities and immediately see ranking changes.
10. Uncertainty is visible.
