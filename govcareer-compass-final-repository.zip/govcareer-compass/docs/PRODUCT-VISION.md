# Product Vision

GovCareer Compass is a personalized government-career discovery and decision-support platform.

It is not merely a vacancy list and not merely an AI chatbot.

Primary journey:
Education → eligibility → preferences → family/lifestyle constraints → career-fit scoring → ranked recommendations → explanation → comparison → exam/preparation guidance.

Initial active coverage:
- Central Government
- West Bengal Government
- English
- Bengali

Long-term coverage:
- All Indian states
- Additional Indian languages
- Current recruitment monitoring
- Secure AI Career Assistant
