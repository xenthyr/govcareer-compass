# Source Standards

Priority:
1. Current official recruitment notification
2. Official service/recruitment rule
3. Official finance/pay rule
4. Official department/directorate page
5. Official cadre/strength/annual-report document
6. Reputable secondary cross-check
7. Analytical estimate

Confidence:
- HIGH
- MEDIUM_HIGH
- MEDIUM
- LOW
- ESTIMATE
- NOT_VERIFIED

Absence of a current vacancy does not prove that a cadre/post does not exist.
