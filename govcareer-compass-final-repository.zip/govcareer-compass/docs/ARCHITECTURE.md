# Architecture

## Layers
1. Data — government career/exam facts
2. Rules — eligibility and scoring rules
3. Application — search/filter/recommendation/comparison
4. Presentation — HTML/CSS/UI
5. AI — future conversational explanation layer

## Deployment
GitHub = source of truth  
Vercel = primary deployment  
GitHub Pages = optional static fallback

## Core principle
The same canonical data record should power search cards, detail pages, comparisons, recommendations and future AI answers.

## Future server boundary
Any private API credential must stay outside public browser code.
