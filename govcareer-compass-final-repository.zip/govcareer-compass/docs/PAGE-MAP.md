# Page Map

Core:
- /
- /pages/career-finder.html
- /pages/career-results.html
- /pages/jobs.html
- /pages/exams.html
- /pages/compare.html
- /pages/rankings.html
- /pages/eligibility.html
- /pages/salary.html
- /pages/family.html
- /pages/parents.html
- /pages/location.html
- /pages/housing.html
- /pages/preparation.html
- /pages/confusion-center.html
- /pages/states.html
- /pages/ai.html
- /pages/sources.html
- /pages/glossary.html
- /pages/methodology.html
- /pages/about.html
- /pages/privacy.html
- /pages/404.html

Future detail patterns:
- /jobs/<job-id>
- /exams/<exam-id>
- /states/<state-id>
