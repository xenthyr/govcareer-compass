# 60-Day Sustainable Build Plan — 3 to 4 Hours/Day

## Week 1 — Foundation
Day 1: create repository, README, security, contribution rules.
Day 2: freeze architecture and page map.
Day 3: freeze data schema and stable ID rules.
Day 4: freeze eligibility model.
Day 5: freeze scoring model.
Day 6: freeze localization model.
Day 7: connect Vercel and test a bare deployment.

## Week 2 — Design System
Day 8: design tokens.
Day 9: reset/base/layout.
Day 10: cards/buttons/badges.
Day 11: forms/tables.
Day 12: charts/score components.
Day 13: header/footer/mobile navigation.
Day 14: accessibility/reduced motion.

## Week 3 — Landing Page
Day 15: hero.
Day 16: problem/solution.
Day 17: search and global actions.
Day 18: state selector.
Day 19: language selector.
Day 20: theme.
Day 21: responsive polish.

## Week 4 — Career Finder
Day 22: questionnaire state.
Day 23: education/qualification questions.
Day 24: subject/specialist conditions.
Day 25: career interests.
Day 26: family/parents.
Day 27: location/transfer/night duty.
Day 28: branching and validation.

## Week 5 — Eligibility
Day 29: hard eligibility.
Day 30: subject-specific rules.
Day 31: typing/language/licence.
Day 32: physical/medical.
Day 33: lower-level/overqualification logic.
Day 34: test cases.
Day 35: eligibility UI.

## Week 6 — Recommendations
Day 36: preference weights.
Day 37: positive metrics.
Day 38: burden metrics.
Day 39: ranking.
Day 40: explanations.
Day 41: results page.
Day 42: standard test profiles.

## Weeks 7–8 — Priority Data
Day 43: WBCS/WBPSC priority set.
Day 44: Kolkata Police/WBP priority set.
Day 45: Panchayat/state admin.
Day 46: School/other state routes.
Day 47: SSC CGL.
Day 48: SSC other priority routes.
Day 49: UPSC.
Day 50: Railways/RPF.
Day 51: IB/CBI/NIA/NCB.
Day 52: Postal/other Central.
Day 53: source audit.
Day 54: eligibility audit.
Day 55: pay audit.
Day 56: job-profile audit.
Day 57: comparison tools.
Day 58: salary/housing/family tools.
Day 59: mobile/accessibility/SEO.
Day 60: release audit and first public beta.

## Daily rule
At the end of each session, commit one coherent milestone and stop. Do not extend the day's scope indefinitely.
