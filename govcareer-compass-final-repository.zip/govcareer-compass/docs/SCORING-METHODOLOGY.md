# Scoring Methodology

Positive metrics: higher is better.
- salary
- authority
- family
- parent care
- location stability
- safety
- work-life
- career growth
- housing advantage

Burden metrics: higher is worse.
- stress
- physical risk
- transfer burden
- night-duty burden

The data model stores metric direction explicitly. A burden must never be accidentally rewarded.

Every deployed recommendation model has a `scoringModelVersion`.
