# Data Model

Core entities:
- state
- government
- department
- organisation
- service/cadre
- post
- exam
- recruitment route
- eligibility rule
- pay structure
- location/posting
- housing
- promotion
- benefits
- source
- assessment question
- scoring rule

## Stable IDs
IDs are language-neutral and permanent.

## Facts vs analysis
Facts: qualification, age, pay, recruitment route, physical standards, official duties, source.
Analysis: family compatibility, parent-care compatibility, location fit, stress assessment, English advantage, preference score.

## Missing values
Use explicit tokens:
- NOT_PUBLICLY_VERIFIED
- NOT_APPLICABLE
- ESTIMATE
- HISTORICAL
- CURRENTLY_UNCLEAR
