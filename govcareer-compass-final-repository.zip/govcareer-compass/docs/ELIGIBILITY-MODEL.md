# Eligibility Model

Eligibility is evaluated before preference scoring.

A — DIRECTLY_ELIGIBLE  
B — CONDITIONALLY_ELIGIBLE  
C — NOT_ELIGIBLE

Conditional flags may include:
- mathematics
- statistics
- economics
- language
- typing
- shorthand
- computer proficiency
- driving licence
- physical/medical
- experience
- professional qualification
- domicile/reservation conditions

Higher education does not automatically cure a missing specialist credential.

Lower-entry jobs must separately track whether higher qualification is:
- explicitly allowed
- not addressed
- restricted
- exact qualification required
- current-notification dependent
