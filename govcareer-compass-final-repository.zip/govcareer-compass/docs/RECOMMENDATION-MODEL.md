# Recommendation Model

## Stage 1 — Hard eligibility
Remove careers the user cannot pursue under the active rule set.

## Stage 2 — Preference matching
Rank eligible careers according to user priorities.

Dimensions:
- salary
- authority
- family
- parent care
- location
- safety
- work-life
- career growth
- housing
- stress burden
- risk burden
- transfer burden
- night-duty burden

Every result must explain:
- why recommended
- what conflicts with preferences
- confidence/source basis

Recommendation scores are analytical decision aids, not official rankings.
