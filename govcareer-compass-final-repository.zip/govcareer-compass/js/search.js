window.SearchService={search:(jobs,q)=>{q=String(q||'').trim().toLowerCase();return q?jobs.filter(j=>JSON.stringify(j).toLowerCase().includes(q)):jobs}};
