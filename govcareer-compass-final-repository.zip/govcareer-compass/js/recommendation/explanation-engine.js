window.ExplanationEngine={explain:job=>({reasons:[],conflicts:[]})};
