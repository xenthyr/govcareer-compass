window.RankingEngine={rank:(jobs,p)=>jobs.map(job=>({job,score:PreferenceEngine.score(job,p)})).sort((a,b)=>b.score-a.score)};
