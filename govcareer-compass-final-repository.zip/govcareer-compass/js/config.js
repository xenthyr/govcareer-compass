window.APP_CONFIG=Object.freeze({
  appVersion:"0.1.0",
  defaultLanguage:"en",
  defaultTheme:"system",
  scoringModelVersion:"1.0.0",
  supportedLanguages:["en","bn"],
  activeStateIds:["west-bengal"]
});
