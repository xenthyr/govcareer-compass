// Score bar component scaffold.\n
