// Comparison table component scaffold.\n
