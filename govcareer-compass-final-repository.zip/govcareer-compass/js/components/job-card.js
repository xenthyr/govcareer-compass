// Job card component scaffold.\n
