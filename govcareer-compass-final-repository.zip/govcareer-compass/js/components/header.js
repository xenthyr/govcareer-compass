// Header component scaffold.\n
