// Exam card component scaffold.\n
