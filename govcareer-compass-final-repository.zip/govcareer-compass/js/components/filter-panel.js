// Filter panel component scaffold.\n
