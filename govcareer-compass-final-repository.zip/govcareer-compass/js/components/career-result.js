// Career result component scaffold.\n
