// Source card component scaffold.\n
