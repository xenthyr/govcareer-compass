// Footer component scaffold.\n
