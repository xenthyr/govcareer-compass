window.FilterService={apply:(jobs,f)=>jobs.filter(j=>(!f.government||j.government===f.government)&&(!f.category||j.category===f.category)&&(!f.educationLevel||j.educationLevel===f.educationLevel))};
