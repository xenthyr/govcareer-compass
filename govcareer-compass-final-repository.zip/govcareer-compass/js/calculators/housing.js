// Module scaffold — implement against the permanent data contract.
