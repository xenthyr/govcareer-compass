window.DataNormalizer={normalizeJob:j=>structuredClone(j)};
