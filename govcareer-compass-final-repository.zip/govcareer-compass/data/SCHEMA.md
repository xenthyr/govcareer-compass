# Canonical Data Contract

Every production job should contain:
- stable ID
- identity
- recruitment
- eligibility
- pay
- lifestyle
- location
- housing
- promotion
- family
- analysis
- sources
- confidence
- lastVerified
- dataVersion

No displayed page should expose raw `null`, `undefined` or `NaN`.
