# Contributing

GovCareer Compass is research-first.

Before contributing:
1. Read `docs/SOURCE-STANDARDS.md`.
2. Read `docs/DATA-MODEL.md`.
3. Never invent recruitment facts.
4. Keep official facts separate from analysis.
5. Include source and verification metadata for factual changes.
6. Version any scoring-model change.
7. Run validation before merging.
