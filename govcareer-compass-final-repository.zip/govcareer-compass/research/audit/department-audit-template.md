# Department Audit Template

Department:
Website:
Directorates:
Recruitment authority:
Service rules:
Cadres:
Sanctioned designations:
Current designations:
Class 8:
Class 10:
Class 12:
Graduate:
BA English direct:
BA English conditional:
BA English not eligible:
Direct recruitment:
Promotion-only:
Deputation-only:
Contract:
Current recruitment:
Historical recruitment:
Missing from previous database:
Corrections:
Official sources:
Confidence:
