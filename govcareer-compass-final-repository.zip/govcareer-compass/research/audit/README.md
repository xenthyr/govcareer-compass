# Research Workspace

Record:
- organisation
- document title
- publication date
- exact URL
- claim supported
- current/historical status
- confidence

Never treat absence of a current vacancy as evidence that a cadre does not exist.
