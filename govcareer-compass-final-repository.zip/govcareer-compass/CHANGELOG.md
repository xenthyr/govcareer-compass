# Changelog

## 2026-08-31 — Foundation
- Permanent repository architecture created.
- Data contracts and scoring boundaries defined.
- English/Bengali structure established.
- West Bengal + Central initial scope established.
- Future all-state expansion reserved.
- Vercel-first, GitHub-source-of-truth deployment model documented.
