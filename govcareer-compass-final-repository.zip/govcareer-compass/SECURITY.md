# Security Policy

Never commit API keys, access tokens, passwords, private credentials or private personal data.

The future AI assistant must not expose a provider API key in client-side JavaScript. Add a secure server-side/serverless boundary before activating provider APIs.

Do not publish security-sensitive reports publicly until a proper disclosure process is established.
